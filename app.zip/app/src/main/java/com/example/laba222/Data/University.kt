package com.example.laba222.Data

import java.util.*

data class University(
    val items:List<Faculty>
    )


