package com.example.laba222.ui

import androidx.lifecycle.ViewModel

class StudentViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}